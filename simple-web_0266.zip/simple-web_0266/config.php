<?php
// Koneksi ke database
$config = mysqli_connect("localhost", "root", "", "0266_simpleweb");
if (!$config) {
    die('Gagal terhubung ke MySQLi : ' . mysqli_connect_error());
}
?>