<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include "../config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user = $_POST['username']; // Fixed: Ensure consistency with input field
    $pass = $_POST['password'];

    // Using prepared statements to prevent SQL Injection
    $stmt = mysqli_prepare($config, "SELECT user_nama FROM user WHERE user_nama=? AND user_password=?");
    mysqli_stmt_bind_param($stmt, "ss", $user, $pass);
    mysqli_stmt_execute($stmt);
    $hasil = mysqli_stmt_get_result($stmt);
    $data = mysqli_fetch_assoc($hasil);

    if ($data) {
        $_SESSION['user'] = $data['user_nama'];
        header("Location: halamanuser.php");
        exit();
    } else {
        echo "<script>alert('Username atau password salah!');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>
<h3>Login</h3>
<form method="POST" action="">
    <table>
        <tr>
            <td>Username</td>
            <td>:</td>
            <td><input type="text" name="username" required></td>
        </tr>
        <tr>
            <td>Password</td>
            <td>:</td>
            <td><input type="password" name="password" required></td>
        </tr>
        <tr>
            <td colspan="2">
                <input type="submit" name="login" value="Login">
            </td>
        </tr>
    </table>
</form>
</body>
</html>
